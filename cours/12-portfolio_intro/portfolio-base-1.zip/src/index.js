import './style/main.css'

console.log('ok')